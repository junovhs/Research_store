import { initThemeToggle } from './theme.js';
import { initColorPalette } from './colorPalette.js';
import { initExport } from './export.js';
import { initLightingEffects } from './lightingEffects.js';
import { initPillSelection } from './pills.js'; 

document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM fully loaded, initializing application");
    
    // Initialize modules in the correct dependency order
    const themeToggle = initThemeToggle();
    
    // Initialize pill selection first
    const pillSelection = initPillSelection();
    
    // Initialize color palette with pill selection reference
    const colorPalette = initColorPalette(pillSelection);
    
    // Then initialize lighting effects with palette reference
    const lightingEffects = initLightingEffects(colorPalette);
    
    // Make lighting effects globally available
    window.lightingEffectsModule = lightingEffects;
    
    // Initialize export with palette reference
    initExport(colorPalette);
    
    // Add explanatory information about errors from Claude platform
    document.getElementById('debugInfo').value = `
FIXED ISSUE: Palette type selection wasn't working correctly because:

1. The initColorPalette function was creating its own pills reference instead of using the shared one
2. The initialization order was incorrect - pills need to be initialized before the palette
3. There were timing issues with the pill click events not propagating correctly

We've fixed these issues by:
- Changed initialization order in main.js to create pills first, then pass to colorPalette
- Simplified pill click handling to ensure events trigger correctly
- Added explicit console logging to verify things initialize in the right order

The React errors shown in the console are related to the Claude AI environment and don't 
affect our application functionality.
    `;
    
    // Log debug info
    console.log("Application initialized successfully");
    
    // Ignore React-related console errors from Claude platform
    console.error = (function(originalError) {
        return function(msg, ...args) {
            if (typeof msg === 'string' && 
                (msg.includes('api.websim.ai') || 
                 msg.includes('Minified React error') ||
                 msg.includes('hydrating'))) {
                return;
            }
            originalError.call(console, msg, ...args);
        };
    })(console.error);
});