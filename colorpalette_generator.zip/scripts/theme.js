export function initThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    let isDarkTheme = false;
    
    themeToggle.addEventListener('click', () => {
        isDarkTheme = !isDarkTheme;
        document.documentElement.setAttribute('data-theme', isDarkTheme ? 'dark' : 'light');
    });
    
    return {
        isDarkMode: () => isDarkTheme
    };
}

