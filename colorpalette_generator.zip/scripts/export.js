import { colorUtils } from './colorUtils.js';

export function initExport(colorPalette) {
    const downloadBtn = document.getElementById('downloadBtn');
    
    downloadBtn.addEventListener('click', () => {
        const colors = colorPalette.getColors();
        const paletteNameInput = document.getElementById('paletteName');
        const paletteName = paletteNameInput.value.trim() || "color_palette";
        
        downloadACO(colors, paletteName);
    });
}

export function downloadACO(colors, paletteName) {
    const acoData = createACOFile(colors);
    
    const blob = new Blob([acoData], {type: "application/octet-stream"});
    
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${paletteName}.aco`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
    }, 100);
}

function createACOFile(colors) {
    const colorCount = colors.length;
    const buffer = new ArrayBuffer(4 + (colorCount * 10));
    const view = new DataView(buffer);
    
    view.setUint16(0, 1, false); 
    view.setUint16(2, colorCount, false); 
    
    let offset = 4;
    
    for (let i = 0; i < colorCount; i++) {
        const rgb = colorUtils.hexToRGB(colors[i]);
        
        view.setUint16(offset, 0, false);
        offset += 2;
        
        view.setUint16(offset, Math.round(rgb.r * 257), false);
        offset += 2;
        
        view.setUint16(offset, Math.round(rgb.g * 257), false);
        offset += 2;
        
        view.setUint16(offset, Math.round(rgb.b * 257), false);
        offset += 2;
        
        view.setUint16(offset, 0, false);
        offset += 2;
    }
    
    return new Uint8Array(buffer);
}