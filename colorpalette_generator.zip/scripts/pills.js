export function initPillSelection() {
    const pillContainer = document.querySelector('.pill-select');
    const pills = Array.from(document.querySelectorAll('.pill'));
    let selectedType = "random"; // Default
    const callbacks = [];
    
    // Reset active state for all pills first
    function resetPills() {
        pills.forEach(pill => pill.classList.remove('active'));
    }
    
    // Set up each pill
    pills.forEach(pill => {
        const input = pill.querySelector('input');
        
        // Initial state
        if (input.checked) {
            resetPills();
            pill.classList.add('active');
            selectedType = input.value;
        }
        
        // Direct click on label
        pill.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent default radio behavior
            resetPills();
            pill.classList.add('active');
            input.checked = true;
            selectedType = input.value;
            
            // Notify all listeners
            callbacks.forEach(callback => callback(selectedType));
        });
    });
    
    return {
        getSelectedType: () => selectedType,
        
        // Register callback
        onSelectionChange: (callback) => {
            callbacks.push(callback);
            // Immediately call with current selection to initialize
            callback(selectedType);
        },
        
        // Manually set a selection (used for programmatic control)
        setSelection: (type) => {
            const pill = Array.from(pills).find(p => 
                p.querySelector('input').value === type
            );
            
            if (pill) {
                resetPills();
                pill.classList.add('active');
                pill.querySelector('input').checked = true;
                selectedType = type;
                
                callbacks.forEach(callback => callback(selectedType));
                return true;
            }
            return false;
        }
    };
}