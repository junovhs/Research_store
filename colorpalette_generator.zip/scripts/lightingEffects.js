import { colorUtils } from './colorUtils.js';

export function initLightingEffects(colorPalette) {
    const lightingPresetSelect = document.getElementById('lightingPreset');
    const effectStrengthInput = document.getElementById('effectStrength');
    const effectStrengthDisplay = effectStrengthInput.parentElement.querySelector('.value-display');
    
    let originalColors = [];
    let currentStrength = effectStrengthInput.value / 100;
    
    // Initialize by storing the current colors
    originalColors = colorPalette.getColors();
    
    // Apply effect when selecting from dropdown
    lightingPresetSelect.addEventListener('change', () => {
        applyLightingPreset();
    });
    
    // Handle real-time updates with effect strength slider
    effectStrengthInput.addEventListener('input', () => {
        effectStrengthDisplay.textContent = `${effectStrengthInput.value}%`;
        currentStrength = effectStrengthInput.value / 100;
        applyLightingPreset();
    });
    
    function applyLightingPreset() {
        // Get current palette colors as the base for modifications
        originalColors = colorPalette.getOriginalColors();
        
        const preset = lightingPresetSelect.value;
        const strength = currentStrength;
        
        if (preset === 'none' || originalColors.length === 0) {
            // If no effect, restore the original colors
            colorPalette.restoreOriginalColors();
            return;
        }
        
        let adjustedColors = [];
        
        switch(preset) {
            case 'sunset':
                adjustedColors = applySunsetEffect(originalColors, strength);
                break;
            case 'moonlight':
                adjustedColors = applyMoonlightEffect(originalColors, strength);
                break;
            case 'firelight':
                adjustedColors = applyFirelightEffect(originalColors, strength);
                break;
            case 'overcast':
                adjustedColors = applyOvercastEffect(originalColors, strength);
                break;
            case 'winter':
                adjustedColors = applyWinterEffect(originalColors, strength);
                break;
            case 'golden-hour':
                adjustedColors = applyGoldenHourEffect(originalColors, strength);
                break;
            case 'neon':
                adjustedColors = applyNeonEffect(originalColors, strength);
                break;
            case 'underwater':
                adjustedColors = applyUnderwaterEffect(originalColors, strength);
                break;
            case 'desert-heat':
                adjustedColors = applyDesertHeatEffect(originalColors, strength);
                break;
            case 'foggy-morning':
                adjustedColors = applyFoggyMorningEffect(originalColors, strength);
                break;
            case 'sepia':
                adjustedColors = applySepiaEffect(originalColors, strength);
                break;
            case 'dramatic':
                adjustedColors = applyDramaticEffect(originalColors, strength);
                break;
            case 'duotone':
                adjustedColors = applyDuotoneEffect(originalColors, strength);
                break;
            case 'northern-lights':
                adjustedColors = applyNorthernLightsEffect(originalColors, strength);
                break;
            default:
                adjustedColors = [...originalColors];
        }
        
        // Update current colors with adjusted ones
        colorPalette.setColors(adjustedColors, false); // false means don't update originalColors
    }
    
    function applySunsetEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            const brightness = (rgb.r + rgb.g + rgb.b) / 765; // 0-1 scale
            
            // Calculate adjustment factor based on strength
            const highlightFactor = 1 + (0.1 * strength);
            const shadowFactor = 1 - (0.1 * strength);
            
            // Highlights become warmer (more red/yellow)
            // Shadows become cooler (more blue)
            if (brightness > 0.6) {
                // Warm up highlights
                rgb.r = Math.min(255, rgb.r * (1 + (0.1 * strength)));
                rgb.g = Math.min(255, rgb.g * (1 + (0.05 * strength)));
                rgb.b = Math.max(0, rgb.b * (1 - (0.1 * strength)));
            } else if (brightness < 0.4) {
                // Cool down shadows
                rgb.r = Math.max(0, rgb.r * (1 - (0.1 * strength)));
                rgb.g = Math.max(0, rgb.g * (1 - (0.05 * strength)));
                rgb.b = Math.min(255, rgb.b * (1 + (0.15 * strength)));
            }
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    function applyMoonlightEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Desaturate
            const avg = (rgb.r + rgb.g + rgb.b) / 3;
            const desaturationFactor = 0.3 * strength;
            rgb.r = rgb.r * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.g = rgb.g * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.b = rgb.b * (1 - desaturationFactor) + avg * desaturationFactor;
            
            // Add slight blue-green tint
            rgb.g = Math.min(255, rgb.g * (1 + (0.05 * strength)));
            rgb.b = Math.min(255, rgb.b * (1 + (0.1 * strength)));
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }

    function applyFirelightEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            const brightness = (rgb.r + rgb.g + rgb.b) / 765;
            
            if (brightness > 0.5) {
                // Make bright areas more orange-yellow
                rgb.r = Math.min(255, rgb.r * (1 + (0.15 * strength)));
                rgb.g = Math.min(255, rgb.g * (1 + (0.05 * strength)));
                rgb.b = Math.max(0, rgb.b * (1 - (0.2 * strength)));
            } else {
                // Deepen shadows and make them slightly red
                rgb.r = Math.max(0, rgb.r * (1 - (0.2 * strength)));
                rgb.g = Math.max(0, rgb.g * (1 - (0.4 * strength)));
                rgb.b = Math.max(0, rgb.b * (1 - (0.5 * strength)));
            }
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }

    function applyOvercastEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Desaturate heavily
            const avg = (rgb.r + rgb.g + rgb.b) / 3;
            const desaturationFactor = 0.4 * strength;
            rgb.r = rgb.r * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.g = rgb.g * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.b = rgb.b * (1 - desaturationFactor) + avg * desaturationFactor;
            
            // Reduce contrast by pulling toward middle gray
            const contrastFactor = 0.3 * strength;
            rgb.r = rgb.r * (1 - contrastFactor) + 128 * contrastFactor;
            rgb.g = rgb.g * (1 - contrastFactor) + 128 * contrastFactor;
            rgb.b = rgb.b * (1 - contrastFactor) + 128 * contrastFactor;
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }

    function applyWinterEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            const brightness = (rgb.r + rgb.g + rgb.b) / 765;
            
            if (brightness > 0.6) {
                // Add blue to highlights
                rgb.r = Math.max(0, rgb.r * (1 - (0.1 * strength)));
                rgb.b = Math.min(255, rgb.b * (1 + (0.2 * strength)));
            } else if (brightness < 0.4) {
                // Add purple to shadows
                rgb.r = Math.min(255, rgb.r * (1 + (0.1 * strength)));
                rgb.b = Math.min(255, rgb.b * (1 + (0.15 * strength)));
            }
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    function applyGoldenHourEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Add golden glow
            rgb.r = Math.min(255, rgb.r * (1 + (0.2 * strength)));
            rgb.g = Math.min(255, rgb.g * (1 + (0.1 * strength)));
            rgb.b = Math.max(0, rgb.b * (1 - (0.1 * strength)));
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    function applyNeonEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            const hsl = colorUtils.rgbToHSL(rgb.r, rgb.g, rgb.b);
            
            // Increase saturation dramatically
            hsl.s = Math.min(1, hsl.s * (1 + strength));
            
            // Slight boost to brightness
            hsl.l = Math.min(0.9, hsl.l * (1 + (0.15 * strength)));
            
            const newRgb = colorUtils.HSLtoRGB(hsl.h, hsl.s, hsl.l);
            return colorUtils.rgbToHex(newRgb.r, newRgb.g, newRgb.b);
        });
    }
    
    function applyUnderwaterEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Shift toward blue-green
            rgb.r = Math.max(0, rgb.r * (1 - (0.3 * strength)));
            rgb.g = Math.min(255, rgb.g * (1 + (0.1 * strength)));
            rgb.b = Math.min(255, rgb.b * (1 + (0.2 * strength)));
            
            // Slightly desaturate
            const avg = (rgb.r + rgb.g + rgb.b) / 3;
            const desaturationFactor = 0.2 * strength;
            rgb.r = rgb.r * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.g = rgb.g * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.b = rgb.b * (1 - desaturationFactor) + avg * desaturationFactor;
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    function applyDesertHeatEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Shift colors toward warm orange/brown
            rgb.r = Math.min(255, rgb.r * (1 + (0.15 * strength)));
            rgb.g = Math.min(255, rgb.g * (1 + (0.05 * strength)));
            rgb.b = Math.max(0, rgb.b * (1 - (0.25 * strength)));
            
            // Add a slight "dusty" quality by pulling midtones toward tan
            const brightness = (rgb.r + rgb.g + rgb.b) / 765;
            if (brightness > 0.3 && brightness < 0.7) {
                const tanFactor = 0.15 * strength;
                rgb.r = rgb.r * (1 - tanFactor) + 210 * tanFactor;
                rgb.g = rgb.g * (1 - tanFactor) + 180 * tanFactor;
                rgb.b = rgb.b * (1 - tanFactor) + 140 * tanFactor;
            }
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    function applyFoggyMorningEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Desaturate
            const avg = (rgb.r + rgb.g + rgb.b) / 3;
            const desaturationFactor = 0.4 * strength;
            rgb.r = rgb.r * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.g = rgb.g * (1 - desaturationFactor) + avg * desaturationFactor;
            rgb.b = rgb.b * (1 - desaturationFactor) + avg * desaturationFactor;
            
            // Add whitish fog (pull toward white)
            const fogFactor = 0.3 * strength;
            rgb.r = rgb.r * (1 - fogFactor) + 240 * fogFactor;
            rgb.g = rgb.g * (1 - fogFactor) + 240 * fogFactor;
            rgb.b = rgb.b * (1 - fogFactor) + 255 * fogFactor;
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    function applySepiaEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Convert to sepia tone
            const sepiaR = (rgb.r * 0.393 + rgb.g * 0.769 + rgb.b * 0.189);
            const sepiaG = (rgb.r * 0.349 + rgb.g * 0.686 + rgb.b * 0.168);
            const sepiaB = (rgb.r * 0.272 + rgb.g * 0.534 + rgb.b * 0.131);
            
            // Blend original with sepia based on strength
            rgb.r = Math.round(rgb.r * (1 - strength) + sepiaR * strength);
            rgb.g = Math.round(rgb.g * (1 - strength) + sepiaG * strength);
            rgb.b = Math.round(rgb.b * (1 - strength) + sepiaB * strength);
            
            return colorUtils.rgbToHex(Math.min(255, rgb.r), Math.min(255, rgb.g), Math.min(255, rgb.b));
        });
    }
    
    function applyDramaticEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            const brightness = (rgb.r + rgb.g + rgb.b) / 765;
            
            // Increase contrast dramatically
            if (brightness > 0.5) {
                // Make lights lighter
                const factor = 1 + (0.3 * strength);
                rgb.r = Math.min(255, rgb.r * factor);
                rgb.g = Math.min(255, rgb.g * factor);
                rgb.b = Math.min(255, rgb.b * factor);
            
            } else {
                // Make darks darker
                const factor = 1 - (0.4 * strength);
                rgb.r = Math.max(0, rgb.r * factor);
                rgb.g = Math.max(0, rgb.g * factor);
                rgb.b = Math.max(0, rgb.b * factor);
            }
            
            // Add a slight cool tone to shadows and warm tone to highlights
            if (brightness < 0.4) {
                rgb.b = Math.min(255, rgb.b * (1 + (0.1 * strength)));
            } else if (brightness > 0.6) {
                rgb.r = Math.min(255, rgb.r * (1 + (0.1 * strength)));
            }
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    function applyDuotoneEffect(colors, strength) {
        // Define two colors for duotone effect (could be customizable in future)
        const shadowColor = {r: 15, g: 10, b: 60}; // Deep blue
        const highlightColor = {r: 255, g: 210, b: 80}; // Golden yellow
        
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            
            // Calculate brightness
            const brightness = (rgb.r * 0.299 + rgb.g * 0.587 + rgb.b * 0.114) / 255;
            
            // Map brightness to a position between shadow and highlight color
            const r = shadowColor.r + brightness * (highlightColor.r - shadowColor.r);
            const g = shadowColor.g + brightness * (highlightColor.g - shadowColor.g);
            const b = shadowColor.b + brightness * (highlightColor.b - shadowColor.b);
            
            // Blend with original based on strength
            rgb.r = Math.round(rgb.r * (1 - strength) + r * strength);
            rgb.g = Math.round(rgb.g * (1 - strength) + g * strength);
            rgb.b = Math.round(rgb.b * (1 - strength) + b * strength);
            
            return colorUtils.rgbToHex(Math.min(255, rgb.r), Math.min(255, rgb.g), Math.min(255, rgb.b));
        });
    }
    
    function applyNorthernLightsEffect(colors, strength) {
        return colors.map(color => {
            const rgb = colorUtils.hexToRGB(color);
            const brightness = (rgb.r + rgb.g + rgb.b) / 765;
            
            // Shift colors toward green/blue/purple aurora colors
            if (brightness > 0.4) {
                // Choose which aurora color to lean toward based on original hue
                const hueSum = rgb.r + rgb.g * 2 + rgb.b * 3;
                
                if (hueSum % 3 === 0) {
                    // Shift toward green
                    rgb.r = Math.max(0, rgb.r * (1 - (0.3 * strength)));
                    rgb.g = Math.min(255, rgb.g * (1 + (0.3 * strength)));
                    rgb.b = Math.max(0, rgb.b * (1 - (0.1 * strength)));
                } else if (hueSum % 3 === 1) {
                    // Shift toward blue
                    rgb.r = Math.max(0, rgb.r * (1 - (0.3 * strength)));
                    rgb.g = Math.min(255, rgb.g * (1 + (0.1 * strength)));
                    rgb.b = Math.min(255, rgb.b * (1 + (0.3 * strength)));
                } else {
                    // Shift toward purple
                    rgb.r = Math.min(255, rgb.r * (1 + (0.1 * strength)));
                    rgb.g = Math.max(0, rgb.g * (1 - (0.2 * strength)));
                    rgb.b = Math.min(255, rgb.b * (1 + (0.3 * strength)));
                }
                
                // Add a glow effect by increasing brightness slightly
                const glowFactor = 0.15 * strength;
                rgb.r = Math.min(255, rgb.r * (1 + glowFactor));
                rgb.g = Math.min(255, rgb.g * (1 + glowFactor));
                rgb.b = Math.min(255, rgb.b * (1 + glowFactor));
            } else {
                // Make darker areas deep blue-black
                rgb.r = Math.max(0, rgb.r * (1 - (0.4 * strength)));
                rgb.g = Math.max(0, rgb.g * (1 - (0.3 * strength)));
                rgb.b = Math.max(0, rgb.b * (1 - (0.1 * strength)));
            }
            
            return colorUtils.rgbToHex(Math.round(rgb.r), Math.round(rgb.g), Math.round(rgb.b));
        });
    }
    
    return {
        applyEffect: applyLightingPreset
    };
}