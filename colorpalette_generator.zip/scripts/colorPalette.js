import { initPillSelection } from './pills.js';
import { initSliders } from './sliders.js';
import { colorUtils } from './colorUtils.js';

export function initColorPalette(pillSelection) {
    const palettes = [
        document.getElementById('palette1'),
        document.getElementById('palette2'),
        document.getElementById('palette3')
    ];
    
    console.log("Initializing color palette with pill selection:", pillSelection.getSelectedType());
    
    let currentColors = [];
    let originalColors = []; 
    let baseHues = []; // Store base hues for modifications
    let baseColor = '#3366ff'; // Default base color
    let baseColorIndex = -1; // Initialize baseColorIndex
    // Use the provided pillSelection instead of creating a new one
    const sliders = initSliders();
    
    // Initialize color picker
    const baseColorPicker = document.getElementById('baseColorPicker');
    const baseColorDisplay = document.getElementById('baseColorDisplay');
    
    // Set initial base color
    baseColorDisplay.style.backgroundColor = baseColor;
    
    // Show color picker when clicking on the color display
    baseColorDisplay.addEventListener('click', () => {
        baseColorPicker.click();
    });
    
    // Update base color when picker changes
    baseColorPicker.addEventListener('input', (e) => {
        baseColor = e.target.value;
        baseColorDisplay.style.backgroundColor = baseColor;
        generatePaletteFromBase();
    });
    
    // Register change events for real-time updates for sliders
    sliders.onSaturationChange((saturation) => {
        updatePaletteWithCurrentHues(saturation, sliders.getBrightness());
    });
    
    sliders.onBrightnessChange((brightness) => {
        updatePaletteWithCurrentHues(sliders.getSaturation(), brightness);
    });
    
    // Handle pill selection changes
    pillSelection.onSelectionChange((type) => {
        console.log("Pill selection changed to:", type);
        // Clear any existing palette and generate a new one
        currentColors = [];  // Clear current colors to force regeneration
        baseHues = [];       // Clear base hues too
        generatePaletteFromBase();
    });
    
    // Add methods to get/restore original colors
    function getOriginalColors() {
        return [...originalColors];
    }
    
    function restoreOriginalColors() {
        if (originalColors.length > 0) {
            currentColors = [...originalColors];
            updatePaletteUI();
        }
    }
    
    // Update palette with current hues, only changing saturation and brightness relatively
    function updatePaletteWithCurrentHues(saturation, brightness) {
        if (baseHues.length === 0 || currentColors.length === 0) {
            generatePaletteFromBase(); // Generate colors if none exist
            return;
        }
        
        const newColors = [];
        
        // Get the current HSV values of all colors
        const currentHSVs = currentColors.map(color => {
            if (!color) return null; // Skip if color is undefined
            const rgb = colorUtils.hexToRGB(color);
            return colorUtils.rgbToHSV(rgb.r, rgb.g, rgb.b);
        });
        
        // Calculate average current saturation and brightness for non-zero values
        let totalValidColors = 0;
        const avgSat = currentHSVs.reduce((sum, hsv) => {
            if (hsv && hsv.s > 0) {
                totalValidColors++;
                return sum + hsv.s;
            }
            return sum;
        }, 0) / (totalValidColors || 1); // Prevent division by zero
        
        const avgVal = currentHSVs.reduce((sum, hsv) => {
            if (hsv && hsv.v > 0) return sum + hsv.v;
            return sum;
        }, 0) / (totalValidColors || 1);
        
        // Calculate adjustment ratios with safety checks
        const satRatio = avgSat > 0 ? saturation / avgSat : 1;
        const valRatio = avgVal > 0 ? brightness / avgVal : 1;
        
        // Modify each color relatively with null checks
        for (let i = 0; i < currentHSVs.length; i++) {
            const hsv = currentHSVs[i];
            if (!hsv) {
                newColors.push(null); // Preserve null for empty slots
                continue;
            }
            
            // Apply relative adjustments with limits
            const newSat = Math.min(1, Math.max(0.05, hsv.s * satRatio));
            const newVal = Math.min(1, Math.max(0.05, hsv.v * valRatio));
            
            const color = colorUtils.HSVtoHex(hsv.h, newSat, newVal);
            newColors.push(color);
        }
        
        // Update current colors
        currentColors = newColors;
        // Also update original colors if not under an effect
        const lightingPreset = document.getElementById('lightingPreset');
        if (lightingPreset && lightingPreset.value === 'none') {
            originalColors = [...newColors];
        }
        
        // Update UI with new colors
        updatePaletteUI();
    }
    
    function generatePaletteFromBase() {
        console.log("Generating palette from base, type:", pillSelection.getSelectedType());
        const paletteType = pillSelection.getSelectedType();
        const saturation = sliders.getSaturation();
        const brightness = sliders.getBrightness();
        
        // Convert base color to HSV
        const rgb = colorUtils.hexToRGB(baseColor);
        const hsv = colorUtils.rgbToHSV(rgb.r, rgb.g, rgb.b);
        
        // Generate palette using the base color HSV values
        const colors = generatePalette(hsv.h, hsv.s, hsv.v, paletteType);
        
        // Store original colors
        originalColors = [...colors];
        
        // Apply lighting effects if any are selected
        const lightingPreset = document.getElementById('lightingPreset');
        if (lightingPreset && lightingPreset.value !== 'none') {
            if (window.lightingEffectsModule) {
                window.lightingEffectsModule.applyEffect();
            }
        }
    }
    
    function generatePalette(baseHue = null, baseSaturation, baseBrightness, paletteType = null) {
        if (!paletteType) paletteType = pillSelection.getSelectedType();
        console.log("Actually generating palette of type:", paletteType);
        
        // Initialize with empty arrays
        const newColors = new Array(30).fill(null);
        const newHues = new Array(30).fill(null);
        let newBaseColorIndex = -1; // Track the base color index
        
        // Add the base color to the palette for most types
        if (!['shades', 'tints', 'tones'].includes(paletteType)) {
            // Place it in middle of the first row for visibility
            const baseColorPlacement = 4; // 5th position in first row
            newColors[baseColorPlacement] = colorUtils.HSVtoHex(baseHue, baseSaturation, baseBrightness);
            newHues[baseColorPlacement] = baseHue;
            newBaseColorIndex = baseColorPlacement;
        }
        
        // Generate the palette based on type
        switch(paletteType) {
            case 'monochromatic':
                generateMonochromaticPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'analogous':
                generateAnalogousPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'complementary':
                generateComplementaryPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'triadic':
                generateTriadicPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'split-complementary':
                generateSplitComplementaryPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'tetradic':
                generateTetradicPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'square':
                generateSquarePalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'shades':
                generateShadesPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'tints':
                generateTintsPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'tones':
                generateTonesPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'pastels':
                generatePastelsPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'jewel-tones':
                generateJewelTonesPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            case 'earthy':
                generateEarthyPalette(baseHue, baseSaturation, baseBrightness, newColors, newHues);
                break;
            default:
                generateRandomPalette(baseSaturation, baseBrightness, newColors, newHues);
        }
        
        // Fill any remaining null slots with colors
        for (let i = 0; i < newColors.length; i++) {
            if (!newColors[i]) {
                const rowIndex = Math.floor(i / 10);
                // Create a color with slight variations based on position
                const hueVar = (baseHue + (i % 10 - 5) * 0.02 + 1) % 1;
                const satVar = baseSaturation * (0.8 + (i % 3) * 0.1);
                const valVar = baseBrightness * (1 - (rowIndex * 0.1));
                
                newColors[i] = colorUtils.HSVtoHex(hueVar, satVar, valVar);
                newHues[i] = hueVar;
            }
        }
        
        // Update the global arrays
        currentColors = [...newColors];
        baseHues = [...newHues];
        baseColorIndex = newBaseColorIndex;
        
        // Update UI with new colors
        updatePaletteUI();
        
        return newColors;
    }
    
    function generateMonochromaticPalette(baseHue, s, v, colors, hues) {
        // Row 1: Different saturations
        for (let i = 0; i < 10; i++) {
            const sat = 0.2 + (i / 10) * 0.8;
            hues.push(baseHue); // Store base hue
            colors.push(colorUtils.HSVtoHex(baseHue, sat, v));
        }
        
        // Row 2: Different values (brightness)
        for (let i = 0; i < 10; i++) {
            const val = 0.2 + (i / 10) * 0.8;
            hues.push(baseHue); // Store base hue
            colors.push(colorUtils.HSVtoHex(baseHue, s, val));
        }
        
        // Row 3: Slight hue variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (baseHue + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar); // Store base hue with variation
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
    }
    
    function generateAnalogousPalette(baseHue, s, v, colors, hues) {
        // Generate 3 rows of analogous colors
        for (let row = 0; row < 3; row++) {
            for (let i = 0; i < 10; i++) {
                // Spread over ~60° each row
                const hueOffset = (i / 10) * 0.15 - 0.075;
                const rowOffset = (row - 1) * 0.05;
                const hue = (baseHue + hueOffset + rowOffset + 1) % 1;
                
                // Vary saturation and brightness slightly per row
                const rowSat = s * (1 - row * 0.1);
                const rowVal = v * (1 - (2 - row) * 0.1);
                
                hues.push(hue); // Store base hue
                colors.push(colorUtils.HSVtoHex(hue, rowSat, rowVal));
            }
        }
    }
    
    function generateComplementaryPalette(baseHue, s, v, colors, hues) {
        const compHue = (baseHue + 0.5) % 1;
        
        // Row 1: Base hue variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (baseHue + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar); // Store base hue
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 2: Complementary hue variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (compHue + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar); // Store base hue
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 3: Mix of both plus variations in saturation/value
        for (let i = 0; i < 10; i++) {
            const useBase = i < 5;
            const hue = useBase ? baseHue : compHue;
            const satVar = 0.3 + (i % 5) * 0.15;
            const valVar = 0.7 + (i % 5) * 0.07;
            hues.push(hue); // Store base hue
            colors.push(colorUtils.HSVtoHex(hue, satVar, valVar));
        }
    }
    
    function generateTriadicPalette(baseHue, s, v, colors, hues) {
        // Generate three evenly spaced hues
        const hue2 = (baseHue + 1/3) % 1;
        const hue3 = (baseHue + 2/3) % 1;
        
        // Row 1: First hue variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (baseHue + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar); // Store base hue
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 2: Second hue variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (hue2 + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar); // Store base hue
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 3: Third hue variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (hue3 + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar); // Store base hue
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
    }
    
    function generateSplitComplementaryPalette(baseHue, s, v, colors, hues) {
        // Generate split complementary colors
        const comp = (baseHue + 0.5) % 1;
        const splitComp1 = (comp + 0.05) % 1;
        const splitComp2 = (comp - 0.05 + 1) % 1;
        
        // Row 1: Base hue variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (baseHue + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 2: Split complementary 1 variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (splitComp1 + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 3: Split complementary 2 variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (splitComp2 + (i - 5) * 0.02 + 1) % 1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
    }
    
    function generateTetradicPalette(baseHue, s, v, colors, hues) {
        // Generate four evenly spaced hues
        const hue2 = (baseHue + 0.25) % 1;
        const hue3 = (baseHue + 0.5) % 1;
        const hue4 = (baseHue + 0.75) % 1;
        
        // Row 1: First two hues
        for (let i = 0; i < 10; i++) {
            const useFirst = i < 5;
            const hue = useFirst ? baseHue : hue2;
            const hueVar = (hue + (i % 5 - 2) * 0.01 + 1) % 1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 2: Second two hues
        for (let i = 0; i < 10; i++) {
            const useThird = i < 5;
            const hue = useThird ? hue3 : hue4;
            const hueVar = (hue + (i % 5 - 2) * 0.01 + 1) % 1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 3: Mixed variations
        for (let i = 0; i < 10; i++) {
            const index = i % 4;
            const hue = [baseHue, hue2, hue3, hue4][index];
            const sat = 0.3 + (i % 3) * 0.2;
            const val = 0.7 + (i % 3) * 0.1;
            hues.push(hue);
            colors.push(colorUtils.HSVtoHex(hue, sat, val));
        }
    }
    
    function generateSquarePalette(baseHue, s, v, colors, hues) {
        // Generate four evenly spaced hues (90° apart)
        const hue2 = (baseHue + 0.25) % 1;
        const hue3 = (baseHue + 0.5) % 1;
        const hue4 = (baseHue + 0.75) % 1;
        
        // Row 1: First and second hues
        for (let i = 0; i < 10; i++) {
            const hue = i < 5 ? baseHue : hue2;
            const variant = (i % 5) * 0.05;
            const hueVar = (hue + (i % 5 < 3 ? variant : -variant) + 1) % 1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 2: Third and fourth hues
        for (let i = 0; i < 10; i++) {
            const hue = i < 5 ? hue3 : hue4;
            const variant = (i % 5) * 0.05;
            const hueVar = (hue + (i % 5 < 3 ? variant : -variant) + 1) % 1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, s, v));
        }
        
        // Row 3: All four hues with varying saturation
        for (let i = 0; i < 10; i++) {
            const index = Math.floor(i / 2.5);
            const hue = [baseHue, hue2, hue3, hue4][index];
            const satVar = 0.4 + (i % 4) * 0.15;
            hues.push(hue);
            colors.push(colorUtils.HSVtoHex(hue, satVar, v));
        }
    }
    
    function generateShadesPalette(baseHue, s, v, colors, hues) {
        // Create a palette of shades (darker variations)
        // Row 1: Base hue with different values
        for (let i = 0; i < 10; i++) {
            const val = 0.9 - (i / 10) * 0.8; // From light to dark
            hues.push(baseHue);
            colors.push(colorUtils.HSVtoHex(baseHue, s, val));
        }
        
        // Row 2: Slightly warmer hue with different values
        const warmHue = (baseHue + 0.02) % 1;
        for (let i = 0; i < 10; i++) {
            const val = 0.9 - (i / 10) * 0.8;
            hues.push(warmHue);
            colors.push(colorUtils.HSVtoHex(warmHue, s * 0.9, val));
        }
        
        // Row 3: Slightly cooler hue with different values
        const coolHue = (baseHue - 0.02 + 1) % 1;
        for (let i = 0; i < 10; i++) {
            const val = 0.9 - (i / 10) * 0.8;
            hues.push(coolHue);
            colors.push(colorUtils.HSVtoHex(coolHue, s * 0.9, val));
        }
    }
    
    function generateTintsPalette(baseHue, s, v, colors, hues) {
        // Create a palette of tints (lighter variations)
        // Row 1: Base hue with decreasing saturation and increasing value
        for (let i = 0; i < 10; i++) {
            const sat = s - (i / 10) * s * 0.9;
            const val = v + ((1 - v) * i / 10);
            hues.push(baseHue);
            colors.push(colorUtils.HSVtoHex(baseHue, sat, val));
        }
        
        // Row 2: Slightly warmer hue with tints
        const warmHue = (baseHue + 0.02) % 1;
        for (let i = 0; i < 10; i++) {
            const sat = s - (i / 10) * s * 0.9;
            const val = v + ((1 - v) * i / 10);
            hues.push(warmHue);
            colors.push(colorUtils.HSVtoHex(warmHue, sat, val));
        }
        
        // Row 3: Slightly cooler hue with tints
        const coolHue = (baseHue - 0.02 + 1) % 1;
        for (let i = 0; i < 10; i++) {
            const sat = s - (i / 10) * s * 0.9;
            const val = v + ((1 - v) * i / 10);
            hues.push(coolHue);
            colors.push(colorUtils.HSVtoHex(coolHue, sat, val));
        }
    }
    
    function generateTonesPalette(baseHue, s, v, colors, hues) {
        // Create a palette of tones (reduced saturation)
        // Row 1: Base hue with decreasing saturation
        for (let i = 0; i < 10; i++) {
            const sat = s - (i / 10) * s * 0.9;
            hues.push(baseHue);
            colors.push(colorUtils.HSVtoHex(baseHue, sat, v));
        }
        
        // Row 2: Slightly shifted hue with decreasing saturation
        const shiftedHue1 = (baseHue + 0.05) % 1;
        for (let i = 0; i < 10; i++) {
            const sat = s - (i / 10) * s * 0.9;
            hues.push(shiftedHue1);
            colors.push(colorUtils.HSVtoHex(shiftedHue1, sat, v));
        }
        
        // Row 3: Another shifted hue with decreasing saturation
        const shiftedHue2 = (baseHue - 0.05 + 1) % 1;
        for (let i = 0; i < 10; i++) {
            const sat = s - (i / 10) * s * 0.9;
            hues.push(shiftedHue2);
            colors.push(colorUtils.HSVtoHex(shiftedHue2, sat, v));
        }
    }
    
    function generatePastelsPalette(baseHue, s, v, colors, hues) {
        // Create a palette of pastels (high value, low-medium saturation)
        const baseSat = Math.min(0.6, s); // Cap saturation for pastels
        const baseVal = Math.max(0.85, v); // Ensure high value for pastels
        
        // Row 1: Base hue family pastels
        for (let i = 0; i < 10; i++) {
            const hueVar = (baseHue + (i - 5) * 0.02 + 1) % 1;
            const sat = baseSat * (0.5 + (i % 5) * 0.1);
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, sat, baseVal));
        }
        
        // Row 2: Complementary pastels
        const compHue = (baseHue + 0.5) % 1;
        for (let i = 0; i < 10; i++) {
            const hueVar = (compHue + (i - 5) * 0.02 + 1) % 1;
            const sat = baseSat * (0.5 + (i % 5) * 0.1);
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, sat, baseVal));
        }
        
        // Row 3: Adjacent hue pastels
        const adjHue1 = (baseHue + 0.1) % 1;
        const adjHue2 = (baseHue - 0.1 + 1) % 1;
        for (let i = 0; i < 10; i++) {
            const hue = i < 5 ? adjHue1 : adjHue2;
            const hueVar = (hue + (i % 5 - 2) * 0.01 + 1) % 1;
            const sat = baseSat * (0.5 + (i % 5) * 0.1);
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, sat, baseVal));
        }
    }
    
    function generateJewelTonesPalette(baseHue, s, v, colors, hues) {
        // Create a palette of jewel tones (rich, deep, saturated colors)
        const baseSat = Math.max(0.7, s); // Ensure high saturation
        const baseVal = Math.min(0.8, Math.max(0.5, v)); // Mid-range value
        
        // Row 1: Base hue jewel tones with variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (baseHue + (i - 5) * 0.03 + 1) % 1;
            const val = baseVal - 0.1 + (i % 3) * 0.05;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, baseSat, val));
        }
        
        // Row 2: Complementary and adjacent jewel tones
        const compHue = (baseHue + 0.5) % 1;
        const adjHue = (baseHue + 0.2) % 1;
        for (let i = 0; i < 10; i++) {
            const hue = i < 5 ? compHue : adjHue;
            const hueVar = (hue + (i % 5 - 2) * 0.02 + 1) % 1;
            const val = baseVal - 0.1 + (i % 3) * 0.05;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, baseSat, val));
        }
        
        // Row 3: Triadic jewel tones
        const triHue1 = (baseHue + 1/3) % 1;
        const triHue2 = (baseHue + 2/3) % 1;
        for (let i = 0; i < 10; i++) {
            const hue = i < 5 ? triHue1 : triHue2;
            const hueVar = (hue + (i % 5 - 2) * 0.02 + 1) % 1;
            const val = baseVal - 0.1 + (i % 3) * 0.05;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, baseSat, val));
        }
    }
    
    function generateEarthyPalette(baseHue, s, v, colors, hues) {
        // Create a palette of earthy colors (muted, natural tones)
        // Adjust the base hue toward earthier territory if needed
        const earthyHueBase = adjustToEarthyHue(baseHue);
        const earthySat = Math.min(0.6, s); // Cap saturation
        
        // Row 1: Brown/tan variations
        for (let i = 0; i < 10; i++) {
            const hueVar = (earthyHueBase + (i - 5) * 0.01 + 1) % 1;
            const sat = earthySat * (0.5 + (i % 5) * 0.1);
            const val = 0.5 + (i % 3) * 0.1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, sat, val));
        }
        
        // Row 2: Green/olive variations
        const greenHue = 0.25; // Green base
        for (let i = 0; i < 10; i++) {
            const hueVar = (greenHue + (i - 5) * 0.02 + 1) % 1;
            const sat = earthySat * (0.3 + (i % 5) * 0.1);
            const val = 0.5 + (i % 3) * 0.1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, sat, val));
        }
        
        // Row 3: Clay/rust/ochre variations
        const rustHue = 0.05; // Rust/orange base
        for (let i = 0; i < 10; i++) {
            const hueVar = (rustHue + (i - 5) * 0.01 + 1) % 1;
            const sat = earthySat * (0.4 + (i % 5) * 0.1);
            const val = 0.5 + (i % 3) * 0.1;
            hues.push(hueVar);
            colors.push(colorUtils.HSVtoHex(hueVar, sat, val));
        }
    }
    
    // Helper function to push hue toward earthier tones
    function adjustToEarthyHue(hue) {
        // Earth tones tend to be in yellow-red-brown range
        // Map any hue to something in the earthy range
        const earthyRanges = [
            {start: 0.02, end: 0.12}, // Reds, browns
            {start: 0.07, end: 0.15}, // Oranges, tans
            {start: 0.25, end: 0.38}  // Olive greens
        ];
        
        // Find closest earthy range
        let minDist = 1;
        let closestEarthyHue = earthyRanges[0].start;
        
        for (const range of earthyRanges) {
            for (const point of [range.start, range.end]) {
                // Calculate distance in hue space (considering the circular nature)
                let dist = Math.abs(hue - point);
                if (dist > 0.5) dist = 1 - dist;
                
                if (dist < minDist) {
                    minDist = dist;
                    closestEarthyHue = point;
                }
            }
        }
        
        // Bias toward the closest earthy hue
        return (hue * 0.3 + closestEarthyHue * 0.7);
    }
    
    function generateRandomPalette(s, v, colors, hues) {
        // Generate 30 random colors (3 rows of 10)
        for (let i = 0; i < 30; i++) {
            const h = Math.random();
            hues.push(h); // Store base hue
            
            // Add variation to saturation and brightness
            const rowIndex = Math.floor(i / 10);
            const satVariation = 0.8 + (Math.random() * 0.4 - 0.2); // 0.8-1.2x variation
            const valVariation = 0.8 + (Math.random() * 0.4 - 0.2); // 0.8-1.2x variation
            
            // As colors get darker, they often get more saturated (artistic principle)
            const adjustedSat = Math.min(1, s * satVariation * (rowIndex === 2 ? 1.1 : 1));
            const adjustedVal = Math.min(1, v * valVariation * (rowIndex === 0 ? 1.1 : 1));
            
            const color = colorUtils.HSVtoHex(h, adjustedSat, adjustedVal);
            colors.push(color);
        }
    }
    
    function updatePaletteUI() {
        // Clear existing swatches
        palettes.forEach(row => row.innerHTML = '');
        
        // Add new swatches for each row
        for (let rowIndex = 0; rowIndex < 3; rowIndex++) {
            for (let i = 0; i < 10; i++) {
                const colorIndex = rowIndex * 10 + i;
                const color = currentColors[colorIndex] || '#ffffff'; // Fallback to white for null
                const swatch = document.createElement('div');
                
                swatch.className = 'color-swatch';
                swatch.style.backgroundColor = color;
                swatch.setAttribute('data-color', color);
                swatch.title = color;
                
                // Mark the base color with an indicator
                if (colorIndex === baseColorIndex) {
                    swatch.classList.add('base-color');
                }
                
                // Add click event to copy color
                swatch.addEventListener('click', () => copyColorToClipboard(swatch, color));
                
                palettes[rowIndex].appendChild(swatch);
            }
        }
    }
    
    function copyColorToClipboard(swatch, color) {
        navigator.clipboard.writeText(color)
            .then(() => {
                swatch.classList.add('copied');
                setTimeout(() => {
                    swatch.classList.remove('copied');
                }, 1000);
            })
            .catch(err => {
                console.error('Failed to copy color: ', err);
            });
    }
    
    function setColors(colors, updateOriginals = true) {
        if (colors && colors.length > 0) {
            currentColors = [...colors];
            if (updateOriginals) {
                originalColors = [...colors];
            }
            updatePaletteUI();
        }
    }
    
    function getColors() {
        return [...currentColors];
    }
    
    // Initialize with default palette based on base color
    console.log("Initial palette generation with type:", pillSelection.getSelectedType());
    generatePaletteFromBase();
    
    return {
        generatePalette,
        getColors,
        setColors,
        getOriginalColors,
        restoreOriginalColors,
        downloadPalette: () => {
            import('./export.js').then(module => {
                const paletteNameInput = document.getElementById('paletteName');
                const paletteName = paletteNameInput.value.trim() || "color_palette";
                module.downloadACO(currentColors, paletteName);
            });
        },
        updateBaseColor: (color) => {
            baseColor = color;
            baseColorDisplay.style.backgroundColor = color;
            generatePaletteFromBase();
        }
    };
}