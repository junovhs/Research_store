export function initSliders() {
    const saturationInput = document.getElementById('saturation');
    const brightnessInput = document.getElementById('brightness');
    const effectStrengthInput = document.getElementById('effectStrength');
    
    const saturationDisplay = saturationInput.parentElement.querySelector('.value-display');
    const brightnessDisplay = brightnessInput.parentElement.querySelector('.value-display');
    const effectStrengthDisplay = effectStrengthInput ? effectStrengthInput.parentElement.querySelector('.value-display') : null;
    
    // Update displays on input without generating palette
    saturationInput.addEventListener('input', () => {
        saturationDisplay.textContent = `${saturationInput.value}%`;
        // Trigger callback for real-time updates
        saturationCallbacks.forEach(callback => callback(saturationInput.value / 100));
    });
    
    brightnessInput.addEventListener('input', () => {
        brightnessDisplay.textContent = `${brightnessInput.value}%`;
        // Trigger callback for real-time updates
        brightnessCallbacks.forEach(callback => callback(brightnessInput.value / 100));
    });
    
    if(effectStrengthInput && effectStrengthDisplay) {
        effectStrengthInput.addEventListener('input', () => {
            effectStrengthDisplay.textContent = `${effectStrengthInput.value}%`;
            // Trigger callback for real-time updates
            effectStrengthCallbacks.forEach(callback => callback(effectStrengthInput.value / 100));
        });
    }
    
    // Callback arrays for real-time updates
    const saturationCallbacks = [];
    const brightnessCallbacks = [];
    const effectStrengthCallbacks = [];
    
    return {
        getSaturation: () => saturationInput.value / 100,
        getBrightness: () => brightnessInput.value / 100,
        getEffectStrength: () => effectStrengthInput ? effectStrengthInput.value / 100 : null,
        onSaturationChange: (callback) => {
            saturationCallbacks.push(callback);
            saturationInput.addEventListener('change', () => callback(saturationInput.value / 100));
        },
        onBrightnessChange: (callback) => {
            brightnessCallbacks.push(callback);
            brightnessInput.addEventListener('change', () => callback(brightnessInput.value / 100));
        },
        onEffectStrengthChange: (callback) => {
            if(effectStrengthInput) {
                effectStrengthCallbacks.push(callback);
                effectStrengthInput.addEventListener('change', () => callback(effectStrengthInput.value / 100));
            }
        }
    };
}