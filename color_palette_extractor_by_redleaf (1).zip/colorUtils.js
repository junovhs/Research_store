// Color conversion utilities
export function rgbToHsl(r, g, b) {
    r /= 255;
    g /= 255;
    b /= 255;
    
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;
    
    if (max === min) {
        h = s = 0; // achromatic
    } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
    }
    
    return {
        h: h * 360,
        s: s * 100,
        l: l * 100
    };
}

export function hslToRgb(h, s, l) {
    h /= 360;
    s /= 100;
    l /= 100;
    
    let r, g, b;
    
    if (s === 0) {
        r = g = b = l; // achromatic
    } else {
        const hue2rgb = (p, q, t) => {
            if (t < 0) t += 1;
            if (t > 1) t -= 1;
            if (t < 1/6) return p + (q - p) * 6 * t;
            if (t < 1/2) return q;
            if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
            return p;
        };
        
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1/3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1/3);
    }
    
    return {
        r: Math.round(r * 255),
        g: Math.round(g * 255),
        b: Math.round(b * 255)
    };
}

export function rgbToCssColor(r, g, b) {
    return `rgb(${r}, ${g}, ${b})`;
}

export function rgbToHex(r, g, b) {
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
}

// Image analysis utilities
export function analyzeImage(img, numColors = 6) {
    // Create canvas and get image data
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    // Resize canvas to match image dimensions
    canvas.width = img.width;
    canvas.height = img.height;
    
    // Draw image on canvas
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    
    // Get image data
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
    
    // Extract pixels
    const pixels = [];
    // Sample pixels (don't process every pixel for performance)
    const samplingRate = Math.max(1, Math.floor((img.width * img.height) / 10000));
    
    for (let i = 0; i < imageData.length; i += 4 * samplingRate) {
        const r = imageData[i];
        const g = imageData[i + 1];
        const b = imageData[i + 2];
        const a = imageData[i + 3];
        
        // Skip transparent pixels
        if (a < 127) continue;
        
        // Skip very dark (near black) and very light (near white) pixels
        if ((r < 20 && g < 20 && b < 20) || (r > 235 && g > 235 && b > 235)) continue;
        
        pixels.push({ r, g, b });
    }
    
    // Extract dominant colors using K-means clustering
    return kMeans(pixels, numColors);
}

// K-means clustering algorithm
function kMeans(pixels, k = 6, maxIterations = 20) {
    if (pixels.length === 0) {
        return Array(k).fill().map(() => ({ r: 0, g: 0, b: 0 }));
    }
    
    // Initialize centroids using improved selection method
    let centroids = initCentroids(pixels, k);
    let assignments = Array(pixels.length).fill(0);
    let iteration = 0;
    let changed = true;
    
    // Iterate until convergence or max iterations
    while (changed && iteration < maxIterations) {
        changed = false;
        
        // Assign pixels to nearest centroid
        for (let i = 0; i < pixels.length; i++) {
            const pixel = pixels[i];
            const closestCentroidIndex = findClosestCentroid(pixel, centroids);
            
            if (assignments[i] !== closestCentroidIndex) {
                assignments[i] = closestCentroidIndex;
                changed = true;
            }
        }
        
        // Update centroids
        const newCentroids = Array(k).fill().map(() => ({ r: 0, g: 0, b: 0, count: 0 }));
        
        for (let i = 0; i < pixels.length; i++) {
            const pixel = pixels[i];
            const centroidIndex = assignments[i];
            
            newCentroids[centroidIndex].r += pixel.r;
            newCentroids[centroidIndex].g += pixel.g;
            newCentroids[centroidIndex].b += pixel.b;
            newCentroids[centroidIndex].count++;
        }
        
        for (let i = 0; i < k; i++) {
            if (newCentroids[i].count > 0) {
                centroids[i] = {
                    r: Math.round(newCentroids[i].r / newCentroids[i].count),
                    g: Math.round(newCentroids[i].g / newCentroids[i].count),
                    b: Math.round(newCentroids[i].b / newCentroids[i].count)
                };
            }
        }
        
        iteration++;
    }
    
    // Count pixels in each cluster
    const clusterSizes = Array(k).fill(0);
    for (let i = 0; i < assignments.length; i++) {
        clusterSizes[assignments[i]]++;
    }
    
    // Sort centroids by cluster size (descending)
    const centroidsWithSize = centroids.map((centroid, index) => ({
        ...centroid,
        size: clusterSizes[index]
    }));
    
    centroidsWithSize.sort((a, b) => b.size - a.size);
    
    // Return top k centroids
    return centroidsWithSize.slice(0, k).map(c => ({ r: c.r, g: c.g, b: c.b }));
}

// Initialize K-means centroids using the k-means++ algorithm
function initCentroids(pixels, k) {
    // Choose first centroid randomly
    const centroids = [pixels[Math.floor(Math.random() * pixels.length)]];
    
    // Choose remaining centroids
    for (let i = 1; i < k; i++) {
        // Calculate distances to nearest centroid for each pixel
        const distances = pixels.map(pixel => {
            return Math.min(...centroids.map(centroid => 
                colorDistance(pixel, centroid)
            ));
        });
        
        // Calculate sum of squared distances
        const distanceSum = distances.reduce((sum, dist) => sum + dist * dist, 0);
        
        // Choose next centroid with probability proportional to squared distance
        let random = Math.random() * distanceSum;
        let index = 0;
        
        for (let j = 0; j < distances.length; j++) {
            random -= distances[j] * distances[j];
            if (random <= 0) {
                index = j;
                break;
            }
        }
        
        centroids.push(pixels[index]);
    }
    
    return centroids;
}

// Calculate Euclidean distance between colors
function colorDistance(color1, color2) {
    const rDiff = color1.r - color2.r;
    const gDiff = color1.g - color2.g;
    const bDiff = color1.b - color2.b;
    
    return Math.sqrt(rDiff * rDiff + gDiff * gDiff + bDiff * bDiff);
}

// Find the closest centroid to a given color
function findClosestCentroid(color, centroids) {
    let minDistance = Infinity;
    let closestCentroidIndex = 0;
    
    for (let i = 0; i < centroids.length; i++) {
        const distance = colorDistance(color, centroids[i]);
        if (distance < minDistance) {
            minDistance = distance;
            closestCentroidIndex = i;
        }
    }
    
    return closestCentroidIndex;
}