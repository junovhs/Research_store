import { analyzeImage, rgbToHsl, hslToRgb, rgbToCssColor, rgbToHex } from './colorUtils.js';
import { config } from './config.js';

document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('file-input');
    const uploadArea = document.getElementById('upload-area');
    const paletteDisplay = document.getElementById('palette-display');
    const paletteContainer = document.getElementById('palette-container');
    const emptyPaletteMessage = document.querySelector('.empty-palette-message');
    const paletteActions = document.getElementById('palette-actions');
    const downloadButton = document.getElementById('download-palette');
    const copyHslButton = document.getElementById('copy-hsl');
    const downloadSwatchesButton = document.getElementById('download-swatches');
    const colorSlider = document.getElementById('color-slider');
    const colorCountDisplay = document.getElementById('color-count');
    const paletteView = document.getElementById('palette-view');
    const paletteTitle = document.getElementById('palette-title');
    const paletteTitleInput = document.getElementById('palette-title-input');
    const editPencilIcon = document.getElementById('edit-pencil-icon');
    const modeToggle = document.getElementById('mode-toggle');
    
    // Initially hide the palette view
    paletteView.style.display = 'none';
    
    // Set up color palette title editing
    let isEditingTitle = false;
    
    // Initialize color mode
    let colorMode = "dominant"; // Default mode
    
    function toggleEditTitle() {
        isEditingTitle = !isEditingTitle;
        
        if (isEditingTitle) {
            paletteTitle.style.display = 'none';
            editPencilIcon.style.display = 'none';
            paletteTitleInput.style.display = 'block';
            paletteTitleInput.value = paletteTitle.textContent;
            paletteTitleInput.focus();
        } else {
            paletteTitle.style.display = 'inline';
            editPencilIcon.style.display = 'inline';
            paletteTitleInput.style.display = 'none';
            paletteTitle.textContent = paletteTitleInput.value;
        }
    }
    
    paletteTitle.addEventListener('click', toggleEditTitle);
    editPencilIcon.addEventListener('click', toggleEditTitle);
    
    paletteTitleInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            toggleEditTitle();
        }
    });
    
    // Handle mode toggle
    modeToggle.addEventListener('change', () => {
        colorMode = modeToggle.checked ? "chromatic" : "dominant";
        
        if (currentImage) {
            processImageWithColorCount(currentImage, parseInt(colorSlider.value));
        }
    });

    // Set up event listeners
    uploadArea.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect);
    downloadButton.addEventListener('click', downloadPalette);
    copyHslButton.addEventListener('click', copyHslValues);
    downloadSwatchesButton.addEventListener('click', downloadProcreateSwatches);
    
    // Move color slider initial setup
    const sliderContainer = document.querySelector('.slider-container');
    document.querySelector('.palette-title-row').appendChild(sliderContainer);
    
    if (colorSlider) {
        colorSlider.addEventListener('input', handleColorSliderChange);
        colorSlider.min = "3";
        colorSlider.max = config.maxColors.toString();
        colorSlider.value = config.numColors.toString();
        colorCountDisplay.textContent = config.numColors;
    }

    let extractedColors = [];
    let currentImage = null;

    // Drag and drop setup
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('drag-over');
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('drag-over');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('drag-over');
        
        if (e.dataTransfer.files.length) {
            handleFiles(e.dataTransfer.files);
        }
    });

    // Clipboard paste functionality
    document.addEventListener('paste', (e) => {
        const items = e.clipboardData?.items;
        if (!items) return;

        for (let i = 0; i < items.length; i++) {
            if (items[i].type.indexOf('image') !== -1) {
                const blob = items[i].getAsFile();
                const file = new File([blob], "pasted-image.png", { type: blob.type });
                handleFiles([file]);
                break;
            }
        }
    });

    function handleFileSelect(e) {
        handleFiles(e.target.files);
    }

    function handleFiles(files) {
        if (files.length === 0) return;
        
        const file = files[0];
        if (!file.type.match('image.*')) {
            alert('Please select an image file.');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            // Show palette view and create/update thumbnail
            paletteView.style.display = 'flex';
            
            // Create or update thumbnail
            let thumbnailContainer = document.querySelector('.image-thumbnail');
            if (!thumbnailContainer) {
                thumbnailContainer = createImageThumbnail();
                paletteView.appendChild(thumbnailContainer);
            }
            
            const thumbnailImg = thumbnailContainer.querySelector('img');
            thumbnailImg.src = e.target.result;
            
            // Hide upload area
            uploadArea.style.display = 'none';
            
            currentImage = e.target.result;
            
            // Show loading indicator
            showLoading();
            
            // Process the image after a short delay to allow the UI to update
            setTimeout(() => {
                processImageWithColorCount(e.target.result, parseInt(colorSlider.value));
            }, 100);
        };
        reader.readAsDataURL(file);
    }
    
    function createImageThumbnail() {
        const thumbnailContainer = document.createElement('div');
        thumbnailContainer.className = 'image-thumbnail';
        
        const thumbnailImg = document.createElement('img');
        thumbnailContainer.appendChild(thumbnailImg);
        
        return thumbnailContainer;
    }

    function handleColorSliderChange(e) {
        const numColors = parseInt(e.target.value);
        colorCountDisplay.textContent = numColors;
        
        if (currentImage) {
            processImageWithColorCount(currentImage, numColors);
        }
    }

    function clearImage() {
        // Show upload area
        uploadArea.style.display = 'block';
        
        // Remove thumbnail
        const thumbnailContainer = document.querySelector('.image-thumbnail');
        if (thumbnailContainer) {
            thumbnailContainer.remove();
        }
        paletteView.style.display = 'none';
        paletteDisplay.innerHTML = '';
        emptyPaletteMessage.style.display = 'block';
        paletteActions.hidden = true;
    }

    function showLoading() {
        paletteDisplay.innerHTML = `
            <div class="loading-indicator">
                <div class="spinner"></div>
            </div>
        `;
        emptyPaletteMessage.style.display = 'none';
    }

    function processImageWithColorCount(imageSrc, numColors) {
        const img = new Image();
        img.onload = () => {
            // Extract dominant colors
            extractedColors = analyzeImage(img, numColors);
            
            // Arrange colors based on selected mode
            if (colorMode === "chromatic" || (colorMode === "dominant" && numColors > 6)) {
                extractedColors = arrangeColorsInChromaticOrder(extractedColors);
            }
            
            displayColorPalette(extractedColors);
        };
        img.src = imageSrc;
    }

    function arrangeColorsInChromaticOrder(colors) {
        // Convert colors to HSL for sorting
        const colorsWithHsl = colors.map(color => {
            const { r, g, b } = color;
            const hsl = rgbToHsl(r, g, b);
            return { color, hsl };
        });
        
        // Group colors by hue ranges (red, orange, yellow, etc.)
        const hueRanges = [
            { name: 'Red', min: 355, max: 360 }, // Red wraps around
            { name: 'Red', min: 0, max: 10 },
            { name: 'Orange', min: 10, max: 45 },
            { name: 'Yellow', min: 45, max: 70 },
            { name: 'Green', min: 70, max: 160 },
            { name: 'Cyan', min: 160, max: 190 },
            { name: 'Blue', min: 190, max: 260 },
            { name: 'Purple', min: 260, max: 290 },
            { name: 'Magenta', min: 290, max: 335 },
            { name: 'Pink', min: 335, max: 355 }
        ];
        
        // Group colors by hue range
        const groupedColors = {};
        
        colorsWithHsl.forEach(item => {
            const hue = item.hsl.h;
            let rangeName = 'Other';
            
            // Find which range this color belongs to
            for (const range of hueRanges) {
                if ((range.min <= hue && hue < range.max) || 
                    (range.name === 'Red' && (hue >= 355 || hue < 10))) {
                    rangeName = range.name;
                    break;
                }
            }
            
            if (!groupedColors[rangeName]) {
                groupedColors[rangeName] = [];
            }
            
            groupedColors[rangeName].push(item);
        });
        
        // Sort each group by lightness (dark to light)
        Object.keys(groupedColors).forEach(key => {
            groupedColors[key].sort((a, b) => a.hsl.l - b.hsl.l);
        });
        
        // Create ordered hue list and flatten groups
        const orderedColors = [];
        
        // Ensure we go through the hue ranges in spectrum order
        for (const range of hueRanges) {
            if (groupedColors[range.name]) {
                orderedColors.push(...groupedColors[range.name]);
            }
        }
        
        // Add any colors that didn't fit the predefined ranges
        if (groupedColors['Other']) {
            orderedColors.push(...groupedColors['Other']);
        }
        
        // Return just the RGB colors in sorted order
        return orderedColors.map(item => item.color);
    }

    function displayColorPalette(colors) {
        paletteDisplay.innerHTML = '';
        emptyPaletteMessage.style.display = 'none';
        paletteActions.hidden = false;

        // Create 30 slots (3 rows of 10)
        const totalSlots = 30;
        
        // Add Clear button if it doesn't exist
        if (!document.getElementById('clear-image')) {
            const clearButton = document.createElement('button');
            clearButton.id = 'clear-image';
            clearButton.textContent = 'Clear';
            clearButton.style.backgroundColor = 'var(--light-color)';
            clearButton.style.color = 'var(--dark-color)';
            clearButton.addEventListener('click', clearImage);
            paletteActions.prepend(clearButton);
        }
        
        // Set palette container to full width
        paletteDisplay.style.width = '100%';
        
        // Fill available colors
        for (let i = 0; i < totalSlots; i++) {
            const colorItem = document.createElement('div');
            colorItem.className = 'color-item';
            
            if (i < colors.length) {
                const { r, g, b } = colors[i];
                const hsl = rgbToHsl(r, g, b);
                const hexColor = rgbToHex(r, g, b);
                
                colorItem.innerHTML = `
                    <div class="color-sample" style="background-color: rgb(${r}, ${g}, ${b})"></div>
                    <div class="color-info">
                        <p>HEX: <span class="color-value">${hexColor}</span></p>
                        <p>RGB: <span class="color-value">rgb(${r}, ${g}, ${b})</span></p>
                        <p>HSL: <span class="color-value">hsl(${Math.round(hsl.h)}, ${Math.round(hsl.s)}%, ${Math.round(hsl.l)}%)</span></p>
                    </div>
                `;
            } else {
                // Empty slot
                colorItem.innerHTML = '<div class="empty-color-slot"></div>';
            }
            
            paletteDisplay.appendChild(colorItem);
        }
    }

    function downloadPalette() {
        if (paletteDisplay.children.length === 0) return;
        
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const colors = Array.from(paletteDisplay.querySelectorAll('.color-sample'))
            .map(div => div.style.backgroundColor);
        
        // Set canvas size
        canvas.width = colors.length * 100;
        canvas.height = 100;
        
        // Draw color swatches
        colors.forEach((color, index) => {
            ctx.fillStyle = color;
            ctx.fillRect(index * 100, 0, 100, 100);
        });
        
        // Create download link
        const link = document.createElement('a');
        link.download = 'color-palette.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
    }

    function copyHslValues() {
        if (paletteDisplay.children.length === 0) return;
        
        const hslValues = Array.from(paletteDisplay.querySelectorAll('.color-info'))
            .map(info => info.querySelectorAll('.color-value')[2].textContent);
        
        const text = hslValues.join('\n');
        navigator.clipboard.writeText(text)
            .then(() => {
                alert('HSL values copied to clipboard!');
            })
            .catch(err => {
                console.error('Failed to copy HSL values: ', err);
                alert('Failed to copy HSL values to clipboard');
            });
    }

    async function downloadProcreateSwatches() {
        if (extractedColors.length === 0) return;
        
        // Create swatches array in the format expected by Procreate
        const swatches = extractedColors.map(color => {
            // Convert RGB to HSB/HSV
            const { r, g, b } = color;
            const hsl = rgbToHsl(r, g, b);
            
            // Convert HSL to HSB/HSV (in HSB, V=B is equivalent to L but calculated differently)
            // Approximation for conversion
            const h = hsl.h / 360; // Procreate uses 0-1 range for hue
            
            // Adjust saturation and brightness calculations for HSB
            let s, v;
            const l = hsl.l / 100;
            
            if (l === 0) {
                s = 0;
                v = 0;
            } else {
                v = l + (hsl.s / 100) * Math.min(l, 1 - l);
                s = v === 0 ? 0 : 2 * (1 - l / v);
            }
            
            return {
                hue: h,
                saturation: s,
                brightness: v,
                alpha: 1,
                colorSpace: 0 // HSB/HSV color space as used by Procreate
            };
        });
        
        // Fill the remaining slots with white if there are fewer than 30 colors
        while (swatches.length < 30) {
            swatches.push({
                hue: 0,
                saturation: 0,
                brightness: 1, // White
                alpha: 1,
                colorSpace: 0
            });
        }
        
        // Create the Procreate swatches file structure
        const swatchData = [
            {
                "name": paletteTitle.textContent || "Extracted Palette",
                "swatches": swatches.slice(0, 30) // Limit to 30 swatches (Procreate's format)
            }
        ];
        
        // Generate pretty JSON with Procreate's specific formatting
        let jsonStr = JSON.stringify(swatchData, null, 2);
        
        // Adjust spacing around colons in keys (Procreate's format)
        jsonStr = jsonStr.replace(/"(\w+)"\s*:/g, '"$1" :');
        
        try {
            // Create a ZIP archive with the JSON file
            const zip = new JSZip();
            zip.file("Swatches.json", jsonStr);
            const blob = await zip.generateAsync({ type: "blob" });
            
            // Trigger download with the .swatches extension
            saveAs(blob, `${paletteTitle.textContent || "ExtractedPalette"}.swatches`);
        } catch (error) {
            console.error("Error creating Procreate swatches file:", error);
            alert("Failed to create Procreate swatches file. Check console for details.");
        }
    }
});